

1. Importar la base de datos desde el archivo llamado: "BaseDatos" para obetner las tablas, registros y procedimentos almacenados 
o ejecutar los script "Script para Crear base de datos y Tablas" y el procedimiento almacenado lladado: "Script para Crear Procedimientos Almacenados" los cuales se encuentra en la carpeta: "Base de Datos"
2. Abrir el proyecto y ejecutar la solucion ProyectoWebApi.sln,  la cual se encuentra en la carpeta: "ProyectoWebApi" 
3. Abrir en archivo llamado: Inicio el cual se encuentra en la carpeta: "PaginaWeb"
4. En caso de que se requiera visualizar los logs de la trazabilidad se debe configurar la ruta de la carpeta de "logs"
la cual se encuentra en la clase: ProyectoWebApi\WebApi\Data\Logs.cs modificando la variable: "path" por la ruta de la carpeta de logs.
5. De igual manera se relaciona la documentación realizada de las funciones del proyecto mediante el archivo llamaado: "Documentación Productos"



Muchas Gracias
Cordialmente

Raúl Eduardo Bolaños Muñoz
Cali Valle
Celular: 3113962704
Correo: rauleduardo1992@hotmail.com

Saludos y Bendiciones.

